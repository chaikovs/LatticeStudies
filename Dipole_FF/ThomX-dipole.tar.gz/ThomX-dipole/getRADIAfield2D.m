function [ Bz ] = getRADIAfield2D(file)
%GETRADIAFIELD Summary of this function goes here
%   Detailed explanation goes here
Bz=load(file);
